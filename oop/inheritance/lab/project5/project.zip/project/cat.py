# from oop.inheritance.lab.project5.project.animal import Animal

from project.animal import Animal

class Cat(Animal):
    def meow(self):
        return "meowing..."