# from oop.inheritance.lab.project3.project.employee import Employee
# from oop.inheritance.lab.project3.project.person import Person

from project.employee import Employee
from project.person import Person


class Teacher(Person, Employee):
    def teach(self):
        return "teaching..."