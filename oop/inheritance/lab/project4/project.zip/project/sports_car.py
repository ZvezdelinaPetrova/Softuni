# from oop.inheritance.lab.project4.project.car import Car

from project.car import Car


class SportsCar(Car):
    def race(self):
        return "racing..."