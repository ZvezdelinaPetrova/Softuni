# from oop.inheritance.lab.project4.project.vehicle import Vehicle

from project.vehicle import Vehicle

class Car(Vehicle):
    def drive(self):
        return "driving..."