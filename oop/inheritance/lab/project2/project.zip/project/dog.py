# from oop.inheritance.lab.project2.project.animal import Animal

from project.animal import Animal


class Dog(Animal):
    def bark(self):
        return "barking..."
