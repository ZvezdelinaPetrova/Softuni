# from oop.inheritance.exercise.project1.project.child import Child


class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age


