import unittest


from project.hero import Hero
# from oop.testing.exercise.hero.hero import Hero


class HeroTest(unittest.TestCase):
    def test_initialization(self):
        hero = Hero("Deli", 5, 20, 2)
        self.assertEqual("Deli", hero.username)
        self.assertEqual(5, hero.level)
        self.assertEqual(20, hero.health)
        self.assertEqual(2, hero.damage)

    def test_str_function(self):
        hero = Hero("Deli", 5, 20, 2)
        hero.__str__()
        expected = f"Hero Deli: 5 lvl\n" \
               f"Health: 20\n" \
               f"Damage: 2\n"
        actual = hero.__str__()
        self.assertEqual(expected, actual)

    def test_battle_username(self):
        hero = Hero("Deli", 5, 20, 2)
        hero2 = Hero("Deli", 4, 15, 3)
        with self.assertRaises(Exception) as ex:
            hero.battle(hero2)
        self.assertEqual("You cannot fight yourself", str(ex.exception))

    def test_battle_health(self):
        hero = Hero("Deli", 5, 0, 2)
        hero2 = Hero("WWW", 2, 30, 3)
        with self.assertRaises(ValueError) as ex:
            hero.battle(hero2)
        self.assertEqual("Your health is lower than or equal to 0. You need to rest", str(ex.exception))

    def test_battle_health_enemy_not_enough(self):
        hero = Hero("Deli", 5, 30, 2)
        hero2 = Hero("WWW", 2, 0, 3)
        with self.assertRaises(ValueError) as ex:
            hero.battle(hero2)
        self.assertEqual(f"You cannot fight WWW. He needs to rest", str(ex.exception))

    def test_battle_test_health_hero_and_enemy(self):
        hero = Hero("Deli", 5, 20, 2)
        hero2 = Hero("WWW", 3, 30, 3)
        hero.battle(hero2)
        # hero_damage = hero.level * hero.damage # 10
        # hero2_damage = hero2.level * hero2.damage # 9
        actual = hero.health
        self.assertEqual(11, actual)
        hero2.battle(hero)
        actual1 = hero2.health
        self.assertEqual(20, actual1)

    def test_heroes_game_equal(self):
        hero = Hero("Deli", 5, 5, 3)
        hero2 = Hero("WWW", 5, 5, 3)
        expected = hero.battle(hero2)
        self.assertEqual("Draw", expected)

    def test_hero_game_win(self):
        hero = Hero("Deli", 5, 500, 3)
        hero2 = Hero("WWW", 5, 5, 3)
        expected = hero.battle(hero2)
        hero.health = 505
        hero.damage = 8
        hero.level = 6
        self.assertEqual("You win", expected)

    def test_hero_game_lose(self):
        hero = Hero("Deli", 5, 5, 3)
        hero2 = Hero("WWW", 5, 500, 3)
        expected = hero.battle(hero2)
        hero2.health = 505
        hero2.damage = 8
        hero2.level = 6
        self.assertEqual("You lose", expected)


if __name__ == '__main__':
    unittest.main()