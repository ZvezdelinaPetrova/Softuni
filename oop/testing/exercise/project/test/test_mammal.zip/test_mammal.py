import unittest

from project.mammal import Mammal
# from oop.testing.exercise.project.mammal import Mammal


class TestMammal(unittest.TestCase):

    def test_initialization(self):
        mammal = Mammal("Puppy", "female", "woof")
        self.assertEqual("female", mammal.type)
        self.assertEqual("woof", mammal.sound)
        self.assertEqual("animals", mammal._Mammal__kingdom)

    def test_make_sound(self):
        mammal = Mammal("Puppy", "female", "woof")
        expected = f"Puppy makes woof"
        actual = mammal.make_sound()
        self.assertEqual(expected, actual)

    def test_get_kingdom(self):
        mammal = Mammal("Puppy", "female", "woof")
        expected = "animals"
        actual = mammal.get_kingdom()
        self.assertEqual(expected, actual)

    def test_info(self):
        mammal = Mammal("Puppy", "female", "woof")
        expected = f"Puppy is of type female"
        actual = mammal.info()
        self.assertEqual(expected, actual)


if __name__ == '__main__':
    unittest.main()
