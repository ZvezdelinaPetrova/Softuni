import unittest


from project.student import Student
# from oop.testing.exercise.student.student import Student


class TestStudent(unittest.TestCase):
    def test_initialization(self):
        student = Student("Deli", courses=None)
        self.assertEqual("Deli", student.name)
        self.assertEqual({}, student.courses)

    def test_initialization_2(self):
        student = Student("Deli", {})
        self.assertEqual("Deli", student.name)
        self.assertEqual({}, student.courses)

    def test_enroll_course_already_added(self):
        student = Student("Deli", {})
        student.courses = {"Python": ["shit", "hard"], "JS": ["more_shits", "damn"]}
        for i in student.courses.keys():
            if i == "Python":
                expected = student.enroll("Python", "d", "v")
                self.assertEqual("Course already added. Notes have been updated.", expected)

    def test_enroll_notes_y(self):
        student = Student("Deli", {})
        student.courses = {"Python": ["shit", "hard"], "JS": ["more_shits", "damn"]}
        actual = student.enroll("PHP", "d", "Y")
        student.courses["PHP"] = "d"
        self.assertEqual("Course and course notes have been added.", actual)

    def test_enroll_notes_empty(self):
        student = Student("Deli", {})
        student.courses = {"Python": ["shit", "hard"], "JS": ["more_shits", "damn"]}
        actual = student.enroll("PHP", "d", "")
        student.courses["PHP"] = "d"
        self.assertEqual("Course and course notes have been added.", actual)

    def test_enroll_new_course(self):
        student = Student("Deli", {})
        expected = student.enroll("PHP", ["T"], "N")
        self.assertEqual("Course has been added.", expected)
        # self.assertEqual([], student.courses["PHP"])

    # def test_add_notes(self):
    #     student = Student("Deli", {})
    #     student.courses = {"Python": ["shit", "hard"], "JS": ["more_shits", "damn"]}
    #     actual = student.add_notes("Python", "d")
    #     student.courses["Python"].append("d")
    #     self.assertEqual("Notes have been updated", actual)

    # def test_leave_course(self):
    #     student = Student("Deli", {})
    #     student.courses = {"Python": ["shit", "hard"], "JS": ["more_shits", "damn"]}
    #     actual = student.leave_course("Python")
    #     # student.courses["Python"].append("d")
    #     self.assertEqual("Course has been removed", actual)

    def test_add_notes_error(self):
        student = Student("Deli", {})
        student.courses = {"Python": ["shit", "hard"], "JS": ["more_shits", "damn"]}
        with self.assertRaises(Exception) as ex:
            student.add_notes("PHP", "d")
        self.assertEqual("Cannot add notes. Course not found.", str(ex.exception))

    def test_leave_course_error(self):
        student = Student("Deli", {})
        student.courses = {"Python": ["shit", "hard"], "JS": ["more_shits", "damn"]}
        with self.assertRaises(Exception) as ex:
            student.leave_course("PHP")
        self.assertEqual("Cannot remove course. Course not found.", str(ex.exception))


if __name__ == '__main__':
    unittest.main()