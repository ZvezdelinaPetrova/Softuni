from library import Library


class User:
    def __init__(self, user_id, username):
        self.user_id = user_id
        self.username = username
        self.books = []

    def get_book(self, author: str, book_name: str, days_to_return: int, library: Library):
        for author, books in library.books_available.items():
            if book_name not in books:
                for author, books_info in library.rented_books.items():
                    for key, value in books_info:
                        if book_name == key:
                            days_to_return = books_info[key]
                            return f"The book '{book_name}' is already rented and will be available in " \
                                   f"{days_to_return} days!"
        self.books.append(book_name)
        library.rented_books.add({self.username: {book_name : days_to_return}})
        library.books_available.remove({author: [book_name]})
        return f"{book_name} successfully rented for the next {days_to_return} days!"

    def return_book(self, author: str, book_name: str, library: Library):
        if book_name not in self.books:
            return f"{self.username} doesn't have this book in his/her records!"

        self.books.remove(book_name)
        library.books_available[author].appand(book_name)
        library.rented_books[self.username].remove(self.username)

    def info(self):
        return f"{', '.join(x for x in sorted(self.books))}"

    def __str__(self):
        return f"{self.user_id}, {self.username}, {[x for x in self.books]}"
