# from project.hotel import Hotel
# from project.room import Room

from oop.class_methods.lab.project.hotel import Hotel
from oop.class_methods.lab.project.room import Room
hotel = Hotel.from_stars(5)

first_room = Room(1, 3)
second_room = Room(2, 2)
third_room = Room(3, 1)

hotel.add_room(first_room)
hotel.add_room(second_room)
hotel.add_room(third_room)

hotel.take_room(1, 4)
hotel.take_room(1, 2)
hotel.take_room(3, 1)
hotel.take_room(3, 1)

print(hotel.status())


#     def test_free_room(self):
#         room = Room(1, 3)
#         self.hotel.add_room(room)
#         self.hotel.take_room(1, 3)
#         self.hotel.free_room(1)
#         self.assertEqual(self.hotel.guests, 0)
#         self.assertEqual(self.hotel.rooms[0].is_taken, False)
#         self.assertEqual(self.hotel.rooms[0].guests, 0)
#
#     def test_print_status(self):
#         room = Room(1, 3)
#         self.hotel.add_room(room)
#         self.hotel.take_room(1, 3)
#         res = self.hotel.status().strip()
#         actual = 'Hotel Some Hotel has 3 total guests\nFree rooms: \nTaken rooms: 1'
#         self.assertEqual(res, actual)

